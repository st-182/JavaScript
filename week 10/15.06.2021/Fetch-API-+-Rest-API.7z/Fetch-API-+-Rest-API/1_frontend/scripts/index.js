// console.log(`one`);
fetch(`http://localhost:5000/adverts`).then((response) =>
  console.log(response)
);
//   .then((data) => console.log(data));
