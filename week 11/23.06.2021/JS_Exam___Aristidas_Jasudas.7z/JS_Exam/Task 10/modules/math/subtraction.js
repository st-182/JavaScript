export function subtraction(a, b) {
  return a - b;
}
