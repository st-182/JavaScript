// 1. Pasirašome HTML.
// --> Game Container blokas, kuriame:
// --> Susikurti 3 blokus - jie reprezentuos skirtingus vaizdus (tačiau viskas vyks viename psl - index.html)
// 1. START PAGE - MYGTUKAI: CHANGE BG IR START GAME;
// 2. GAME PAGE - SCORE: ; SAUSAINIO NUOTRAUKA; MYGTUKAS GO TO SHOP;
// 3. SHOP PAGE - MYGTUKAS GO BACK TO GAME; + 4 MYGTUKAI APSIPIRKIMUI;
// 2. Su CSS susitvarkome pradinį vaizdą: t.y. pradžioje matome tik start page, tačiau viską išcentruojame, sutvarkome dydžius, apsirašome mygtukus (sukuriame jiems id/klases, juos pasiimsime su JS).
// 3. Su JS apsirašome logiką.
// 1. start page - jame yra mygtukas (Start), kurį paspaudus mums rodomas žaidimo vaizdas, o start mygtukas neberodomas;
// 2. game page:
//     - jame yra užrašas score, kuris keisis kiekvieną kartą paspaudus ant sausainio;
//     - sausainio nuotrauka, kurią spaudinėsime, kad rinktume taškus;
//     - užvedus pelyte ant sausainio nuotraukos - ji padidėja 1.2 karto, pelytę patraukus sumažėja iki originalios. Aprašoma per JS.
//     - mygtukas shop, kurį paspaudus bus atvaizduojama "parduotuvė", tuo tarpu sausainis nebėra atvaizduojamas;
// 3. shop page: jame yra nurodomas bendras surinktų taškų kiekis, ir keli pasirinkimai:
//     - mygtukas BACK - paspaudus vėl atvaizduojamas game page;
//     - mygtukas MAKE COOKIE SPIN. COST 20 POINTS;
//     - mygtukas ADD TWO POINTS ON CLICK. COST 100 POINTS;
//     - mygtukas ADD FIVE POINTS ON CLICK. COST 300 POINTS;
//     - mygtukas CHANGE COOKIE IMAGE TO NEW ONE. COST 150 POINTS;

// variables
const changebg = document.querySelector(`#changebg`);
const start = document.querySelector(`#start`);
const gotoshop = document.querySelector(`#gotoshop`);
const spin = document.querySelector(`#spin`);
const add2 = document.querySelector(`#add2`);
const add5 = document.querySelector(`#add5`);
const goback = document.querySelector(`#goback`);
const imgCookie = document.querySelector(`#imgcookie`);
let startpage = document.querySelector(`#startpage`);
let gamepage = document.querySelector(`#gamepage`);
let shoppage = document.querySelector(`#shoppage`);
let score = 0;
let points = 1;
// events
start.addEventListener(`click`, openGame);
gotoshop.addEventListener(`click`, openShop);
goback.addEventListener(`click`, openGame);
imgCookie.addEventListener(`mouseover`, cookieScale);
imgCookie.addEventListener(`mouseleave`, cookieScaleBack);
imgCookie.addEventListener(`click`, scorePoints);
spin.addEventListener(`click`, spinTheCookie);
add2.addEventListener(`click`, scorePointsX2);
add5.addEventListener(`click`, scorePointsX5);
// logic, functions
function openGame(e) {
  e.preventDefault;
  startpage.style.display = "none";
  gamepage.style.display = "flex";
  shoppage.style.display = "none";
}
function openShop(e) {
  e.preventDefault;
  gamepage.style.display = "none";
  shoppage.style.display = "flex";
}
function cookieScale(e) {
  e.preventDefault;
  imgCookie.style.transform = "scale(1.1)";
}
function cookieScaleBack(e) {
  e.preventDefault;
  imgCookie.style.transform = "scale(1.0)";
}
function scorePoints(e) {
  e.preventDefault;
  score += points;
  updateScore();
}
function updateScore() {
  document.querySelectorAll(`.text`).textContent = `Score: ${score}`;
  
}
function spinTheCookie(e) {
  e.preventDefault;
  spin.style.transform = "scale(1.0)";
  score = score - 25;
}

function scorePointsX2(e) {
  e.preventDefault;
  points = 2;
  score = score - 50;
  updateScore();
}
function scorePointsX5(e) {
  e.preventDefault;
  points = 5;
  score = score - 150;
  updateScore();
}
